from django.contrib import admin

from report.models import Report

# Register your models here.
admin.site.register(Report)